#!/usr/bin/env bash
cd /usr/share/pyshared/vizigrep
python vizigrep
